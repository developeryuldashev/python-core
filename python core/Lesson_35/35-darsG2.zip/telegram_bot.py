from telegram.ext import Updater,CommandHandler,MessageHandler,Filters
from telegram import ReplyKeyboardMarkup
from OwnFilter import python
keyboard =  ReplyKeyboardMarkup([
    ['Bosh sahifa'],
    ['chapga','o\'ngga'],
    ['ortga']
], resize_keyboard=True)
def start(update,context):
    context.bot.send_message(chat_id = update.effective_chat.id, text = 'Bot ishladi',reply_markup = keyboard)
def text(update,context):
    print(update)
    text = update.message.text
    if text == 'tatu':
        context.bot.send_message(chat_id = update.effective_chat.id, text = 'Tatu haqida ma\'lumot')
    if text == 'chapga':
        context.bot.send_message(chat_id=update.effective_chat.id, text='chapga bosildi')
def audio(update,context):
    context.bot.send_message(chat_id = update.effective_chat.id, text = 'audio xabar')
def foto(update,context):
    context.bot.send_message(chat_id = update.effective_chat.id, text = 'rasmli xabar')
def hujjat(update,context):
    context.bot.send_message(chat_id = update.effective_chat.id, text = 'fayl yuborilgan')
def joylashuv(update,context):
    context.bot.send_message(chat_id = update.effective_chat.id, text = 'joylashuv yuborilgan')

updater = Updater(token = '1764688508:AAEznpu_JgW9HsR5-nzxqZEz9NOoxm7y93A',use_context=True)
dispatcher = updater.dispatcher
start_handler = CommandHandler('start', start)
text_handler = MessageHandler(Filters.text,text)
python_handler = MessageHandler(python,text)
audio_handler = MessageHandler(Filters.audio,audio)
foto_handler = MessageHandler(Filters.photo,foto)
doc_handler = MessageHandler(Filters.document,hujjat)
loc_handler = MessageHandler(Filters.location,joylashuv)
dispatcher.add_handler(start_handler)
dispatcher.add_handler(text_handler)
dispatcher.add_handler(audio_handler)
dispatcher.add_handler(foto_handler)
dispatcher.add_handler(doc_handler)
dispatcher.add_handler(loc_handler)
dispatcher.add_handler(python_handler)


updater.start_polling()