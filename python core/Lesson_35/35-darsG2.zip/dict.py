{
    'update_id': 19090397,
    'message':
        {'message_id': 16,
         'date': 1619615848,
         'chat': {
             'id': 494473113,
             'type': 'private',
             'username': 'Trigger_No1',
             'first_name': 'Azimjon',
             'last_name': 'N'
         },
         'text': 'asgddffg',
         'entities': [],
         'caption_entities': [],
         'photo': [],
         'new_chat_members': [],
         'new_chat_photo': [],
         'delete_chat_photo': False,
         'group_chat_created': False,
         'supergroup_chat_created': False,
         'channel_chat_created': False,
         'from':
             {'id': 494473113,
              'first_name': 'Azimjon',
              'is_bot': False,
              'last_name': 'N',
              'username': 'Trigger_No1',
              'language_code': 'ru'
              }
         }
}
