from telegram.ext import MessageFilter
class HandlePython(MessageFilter):
    name = 'Filters.python'

    def filter(self, message):
        return 'python' in message.text


python = HandlePython()