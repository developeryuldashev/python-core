from telegram import ReplyKeyboardMarkup
def start(update,context):
    main_keyboard = ReplyKeyboardMarkup(
        [
            ['🛒 Buyurtma qilish'],
            ['🛍 Buyurtmalarim','⚙️ Sozlamalar'],
            ['✍️ Fikr bildirish']
        ],
        resize_keyboard=True
    )
    name = update.message.chat.first_name
    context.bot.send_message(
        chat_id = update.effective_chat.id,
        text = f'Assalomu alaykum <b>{name}</b>,\nMarhamat kerakli bo\'limni tanlang!',
        parse_mode = 'HTML',
        reply_markup = main_keyboard
    )
    return 'main_menu'

def main_menu(update,context):
    message = update.message.text
    if message == '🛒 Buyurtma qilish':
        order(update,context)
    if message == '🛍 Buyurtmalarim':
        my_orders(update,context)
    if message == '⚙️ Sozlamalar':
        settings(update,context)
    if message == '✍️ Fikr bildirish':
        keyboard = ReplyKeyboardMarkup([['⬅️ Ortga']],resize_keyboard=True)
        context.bot.send_message(
            chat_id=update.effective_chat.id,
            text='''Marhamat, 
                        sizning fikringiz biz uchun o'ta muhim
                        ''',
            reply_markup=keyboard
        )
        return 'feedback'
def order(update,context):
    message = update.message.text
    if message == '🛒 Buyurtma qilish':
        context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo=open('files/order.jpg','rb'),
            caption='Marhamat buyurtma bering'
        )

def my_orders(update,context):
    context.bot.send_message(
        chat_id=update.effective_chat.id,
        text='Avval backendni ko\'tar'
    )

def feedback(update,context):
    message = update.message.text
    main_keyboard = ReplyKeyboardMarkup(
        [
            ['🛒 Buyurtma qilish'],
            ['🛍 Buyurtmalarim', '⚙️ Sozlamalar'],
            ['✍️ Fikr bildirish']
        ],
        resize_keyboard=True
    )
    if message == '⬅️ Ortga':
        context.bot.send_message(
            chat_id=update.effective_chat.id,
            text='''Fikringiz uchun rahmat!''',
            reply_markup = main_keyboard
        )
        return 'main_menu'
    context.bot.send_message(
        chat_id=update.effective_chat.id,
        text='''Fikringiz uchun rahmat!'''
    )
    name = update.message.chat.first_name
    context.bot.send_message(
        chat_id=494473113,
        text=f'''foydalanuvchi {name} tomonidan yo'llangan fikrlar: 
            {message}
            '''
    )

def settings(update,context):

    context.bot.send_message(
        chat_id=update.effective_chat.id,
        text='Avval backendni ko\'tar'
    )
